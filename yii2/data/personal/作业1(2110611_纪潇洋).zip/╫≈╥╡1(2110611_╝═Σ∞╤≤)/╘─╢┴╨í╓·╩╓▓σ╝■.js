// ==UserScript==
// @name         Stephenbiu
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  An integrated utility panel for various page manipulations.
// @author       YourName
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 创建工具面板
    const panel = document.createElement('div');
    panel.style.position = 'fixed';
    panel.style.top = '10px';
    panel.style.left = '10px';
    panel.style.zIndex = '10000';
    panel.style.backgroundColor = 'white';
    panel.style.border = '1px solid black';
    panel.style.padding = '10px';
    panel.style.borderRadius = '5px';
    panel.style.boxShadow = '0px 0px 5px rgba(0,0,0,0.2)';
    document.body.appendChild(panel);

    // 函数生成随机颜色
    function getRandomColor() {
        return '#' + Math.floor(Math.random() * 16777215).toString(16);
    }

    // 函数创建按钮
    function createButton(text, onClick) {
        const button = document.createElement('button');
        button.textContent = text;
        button.style.margin = '5px';
        button.addEventListener('click', onClick);
        panel.appendChild(button);
    }

    // 更改背景颜色的事件处理器
    function changeBackgroundColor() {
        const color = getRandomColor();
        document.body.style.backgroundColor = color;
    }

    // 显示/隐藏页面元素的事件处理器
    function toggleElements() {
        const elements = document.querySelectorAll('p');
        elements.forEach(function(element) {
            element.style.display = element.style.display === 'none' ? '' : 'none';
        });
    }

    // 滚动到页面顶部的事件处理器
    function scrollToTop() {
        window.scrollTo({top: 0, behavior: 'smooth'});
    }

    // 滚动到页面底部的事件处理器
    function scrollToBottom() {
        window.scrollTo({top: document.body.scrollHeight, behavior: 'smooth'});
    }

    // 创建按钮
    createButton('Change Background Color', changeBackgroundColor);
    createButton('Toggle Elements', toggleElements);
    createButton('Scroll to Top', scrollToTop);
    createButton('Scroll to Bottom', scrollToBottom);
})();


