const EastereggTipTrigged = () => {
    alert("Go to ErwinZhou\'s Github HomePage, then you will see the EasterEgg!")
};

document.addEventListener('click', EastereggTipTrigged);
