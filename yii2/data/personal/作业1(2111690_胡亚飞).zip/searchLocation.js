// ==UserScript==
// @name         地理编码查询
// @namespace    https://github.com/hyf2002
// @version      0.1
// @description  输入地址名，一键查询地址的经纬度
// @author       Yafei Hu
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    // 创建一个容器元素，包含输入框、按钮和结果框
    var container = document.createElement('div');
    container.style.position = 'fixed';
    container.style.top = '200px';
    container.style.right = '10px';
    container.style.backgroundColor = 'rgba(255, 255, 255, 0.8)';
    container.style.padding = '10px';
    container.style.borderRadius = '5px';
    container.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.2)';
    container.style.display = 'flex';
    container.style.flexDirection = 'column';
    container.style.alignItems = 'flex-end';

    // 输入框
    var inputBox = document.createElement('input');
    inputBox.type = 'text';
    inputBox.placeholder = '输入地址查询经纬度';
    inputBox.style.margin = '5px';
    inputBox.style.padding = '5px';
    inputBox.style.border = '1px solid #ccc';
    inputBox.style.borderRadius = '3px';

    // 按钮
    var searchButton = document.createElement('button');
    searchButton.textContent = '查询';
    searchButton.style.margin = '5px';
    searchButton.style.padding = '5px 10px';
    searchButton.style.backgroundColor = '#0074d9';
    searchButton.style.color = 'white';
    searchButton.style.border = 'none';
    searchButton.style.borderRadius = '3px';
    searchButton.style.cursor = 'pointer';

    // 结果显示区域
    var resultDiv = document.createElement('div');
    resultDiv.style.backgroundColor = 'rgba(255, 255, 255, 0.8)';
    resultDiv.style.padding = '10px';
    resultDiv.style.borderRadius = '5px';
    resultDiv.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.2)';
    resultDiv.style.marginTop = '10px';
    resultDiv.style.display = 'block';

    // 添加输入框和按钮到容器
    container.appendChild(inputBox);
    container.appendChild(searchButton);

    // 添加容器和结果框到页面
    document.body.appendChild(container);
    container.appendChild(resultDiv);

    // 查询按钮点击事件处理，输入框按Enter键触发查询
    searchButton.addEventListener('click', function () {
        searchAddress(inputBox.value);
    });

    inputBox.addEventListener('keydown', function (event) {
        if (event.key === 'Enter') {
            searchAddress(inputBox.value);
        }
    });

    // 查询地址的经纬度并显示结果
    function searchAddress(address) {
        var key = 'e3449cb45c2f210d7cc18d6427988ede'; // 高德地图API密钥
        var apiUrl = 'https://restapi.amap.com/v3/geocode/geo';

        var params = {
            address: address,
            key: key
        };

        fetch(apiUrl + '?' + new URLSearchParams(params))
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                if (data.status === '1' && data.count > 0) {
                    var location = data.geocodes[0].location.split(',');
                    var latitude = location[1];
                    var longitude = location[0];
                    resultDiv.style.display = 'block'; // 显示结果框
                    resultDiv.textContent = '经度: ' + longitude + ', 纬度: ' + latitude;
                } else {
                    resultDiv.style.display = 'block'; // 显示结果框
                    resultDiv.textContent = '查询失败';
                }
            })
            .catch(function (error) {
                console.error('查询出错:', error);
                resultDiv.style.display = 'block'; // 显示结果框
                resultDiv.textContent = '查询出错';
            });
    }
})();
